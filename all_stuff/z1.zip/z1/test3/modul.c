
/*
 *  Zestaw wazniejszych stalych
 */

const double PI = 3.141593;
const double E  = 2.718282;
