
double Dodaj(double Skl1, double Skl2)
{
  return Skl1 + Skl2;
}
