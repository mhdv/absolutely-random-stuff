for i;do  rm *.o | gcc -c czytaj.c | gcc -c konturowanie.c | gcc -c wyswietl.c | gcc korekrcja.c | gcc -c opcje.c | gcc -c zapisz.c | gcc -c informacje.c | gcc -c progowanie.c; done
